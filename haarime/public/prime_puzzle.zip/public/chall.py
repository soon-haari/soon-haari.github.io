from Crypto.Util.number import isPrime
from string import digits
from secret import banner, flag

def challenge(inp, l):
	try:
		assert len(inp) == l**2
		assert all([c in digits for c in inp])

		for i in range(l):
			line_v = ""
			line_h = ""
			for j in range(l):
				line_v += inp[l * i + j]
				line_h += inp[l * j + i]
			assert isPrime(int(line_v)) and isPrime(int(line_v[::-1]))
			assert isPrime(int(line_h)) and isPrime(int(line_h[::-1]))

		line_d1 = ""
		line_d2 = ""
		for i in range(l):
			line_d1 += inp[l * i + i]
			line_d2 += inp[l * i + (l - 1 - i)]
		assert isPrime(int(line_d1)) and isPrime(int(line_d1[::-1]))
		assert isPrime(int(line_d2)) and isPrime(int(line_d2[::-1]))

		assert isPrime(int(inp))

		return True
	except:
		return False

if __name__ == "__main__":
	print(banner)
	assert challenge("".join(open("original_prime33.txt").read().split("\n")), 33)

	if challenge(input("Send 55x55 prime number: "), 55):
		print(flag)
